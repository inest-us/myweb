import React from "react";
import "./contact.css";

const Contact = () => {
  return <section id="contact">Contact</section>;
};

export default Contact;
