import React from "react";
import "./testimonials.css";

const Testimonials = () => {
  return <div>Testimonials</div>;
};

export default Testimonials;
