import React from "react";
import "./about.css";

function About() {
  return <div>About</div>;
}

export default About;
