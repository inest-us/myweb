import React from "react";
import "./experience.css";

const Experience = () => {
  return <div>Experience</div>;
};

export default Experience;
