import React from "react";
import "./services.css";

const Services = () => {
  return <div>Services</div>;
};

export default Services;
