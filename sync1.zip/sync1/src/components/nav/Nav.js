import React from "react";
import "./nav.css";

const Nav = () => {
  return <div>Nav</div>;
};

export default Nav;
